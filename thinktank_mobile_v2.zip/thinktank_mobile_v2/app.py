import os, sqlite3, threading, time, re
from datetime import datetime, timezone, timedelta
from urllib.parse import quote_plus
import xml.etree.ElementTree as ET
import requests
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
DB = "thinktank_v2.db"

SOURCES = [
    ("Reuters", "reuters.com"),
    ("INSS", "inss.org.il"),
    ("CSIS", "csis.org"),
    ("Crisis Group", "crisisgroup.org"),
    ("IISS", "iiss.org"),
    ("RUSI", "rusi.org"),
]

QUERIES = {
    "ایران": "Iran nuclear missiles Israel Gulf",
    "اسرائیل": "Israel Iran security strategy Middle East",
    "خاورمیانه": "Middle East conflict diplomacy security",
    "خلیج فارس": "Gulf Hormuz Saudi UAE Iran",
    "دریای سرخ": "Red Sea shipping Houthis",
    "یمن": "Yemen Houthis Red Sea",
    "اقتصاد و انرژی": "oil gas LNG Hormuz energy Middle East",
    "روسیه و چین": "Russia China Iran Middle East",
}

TOPICS = {
    "تنش مستقیم": ["attack","strike","missile","war","escalat","حمله","موشک","جنگ","درگیری"],
    "هسته‌ای": ["nuclear","uranium","enrichment","IAEA","هسته","غنی","آژانس"],
    "دریایی": ["hormuz","red sea","shipping","navy","maritime","باب المندب","هرمز","کشتیرانی"],
    "انرژی": ["oil","gas","lng","energy","pipeline","نفت","گاز","انرژی","خط لوله"],
    "دیپلماسی": ["talks","negotiation","diplomacy","agreement","ceasefire","مذاکره","دیپلماسی","توافق","آتش‌بس"],
    "نیابتی/منطقه‌ای": ["houthi","hezbollah","militia","proxy","یمن","حوثی","حزب الله","نیابتی"],
}

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.execute("""CREATE TABLE IF NOT EXISTS news(
        id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, link TEXT UNIQUE,
        source TEXT, published TEXT, desk TEXT, topic TEXT, importance INTEGER,
        summary TEXT, created_at TEXT)""")
    c.commit(); c.close()

def classify(text):
    t = text.lower()
    scores = {}
    for topic, words in TOPICS.items():
        scores[topic] = sum(1 for w in words if w.lower() in t)
    topic = max(scores, key=scores.get)
    return topic if scores[topic] else "عمومی"

def importance(topic, title):
    high = ["هسته‌ای","تنش مستقیم","دریایی","انرژی"]
    score = 5
    if topic in high: score += 2
    if any(x in title.lower() for x in ["urgent","breaking","حمله","موشک","nuclear","hormuz"]): score += 2
    return min(score,10)

def fetch_rss(desk, query, domain):
    url = f"https://news.google.com/rss/search?q={quote_plus(query+' site:'+domain)}&hl=en-US&gl=US&ceid=US:en"
    try:
        r = requests.get(url, timeout=15, headers={"User-Agent":"ThinkTank-OSINT/2.0"})
        r.raise_for_status()
        root = ET.fromstring(r.text)
    except Exception:
        return 0
    c = db(); count = 0
    for item in root.findall(".//item"):
        title = item.findtext("title") or ""
        link = item.findtext("link") or ""
        pub = item.findtext("pubDate") or ""
        if not title or not link: continue
        topic = classify(title)
        imp = importance(topic,title)
        try:
            c.execute("""INSERT OR IGNORE INTO news
                (title,link,source,published,desk,topic,importance,summary,created_at)
                VALUES(?,?,?,?,?,?,?,?,?)""",
                (title,link,domain,pub,desk,topic,imp,title,datetime.now(timezone.utc).isoformat()))
            count += c.rowcount
        except Exception:
            pass
    c.commit(); c.close()
    return count

def refresh():
    total = 0
    for desk, q in QUERIES.items():
        for source, domain in SOURCES:
            total += fetch_rss(desk,q,domain)
    return total

@app.route("/")
def index(): return render_template("index.html")

@app.route("/api/news")
def api_news():
    limit = min(int(request.args.get("limit",80)),200)
    desk = request.args.get("desk","")
    topic = request.args.get("topic","")
    c=db()
    sql="SELECT * FROM news WHERE 1=1"; args=[]
    if desk: sql += " AND desk=?"; args.append(desk)
    if topic: sql += " AND topic=?"; args.append(topic)
    sql += " ORDER BY importance DESC, id DESC LIMIT ?"; args.append(limit)
    rows=[dict(x) for x in c.execute(sql,args).fetchall()]
    c.close()
    return jsonify(rows)

@app.route("/api/summary")
def summary():
    c=db()
    total=c.execute("SELECT COUNT(*) n FROM news").fetchone()["n"]
    desks=c.execute("SELECT desk,COUNT(*) n FROM news GROUP BY desk ORDER BY n DESC").fetchall()
    topics=c.execute("SELECT topic,COUNT(*) n FROM news GROUP BY topic ORDER BY n DESC").fetchall()
    recent=c.execute("SELECT COUNT(*) n FROM news WHERE id > (SELECT COALESCE(MAX(id),0)-30 FROM news)").fetchone()["n"]
    c.close()
    return jsonify({"total":total,"recent":recent,
                    "desks":[dict(x) for x in desks],
                    "topics":[dict(x) for x in topics]})

@app.route("/api/refresh", methods=["POST"])
def api_refresh():
    n=refresh()
    return jsonify({"added":n,"updated_at":datetime.now().isoformat()})

@app.route("/api/sources")
def sources():
    return jsonify([{"name":a,"domain":b} for a,b in SOURCES])

if __name__=="__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.getenv("PORT","8000")), debug=False)

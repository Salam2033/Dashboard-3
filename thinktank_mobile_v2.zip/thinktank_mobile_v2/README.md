THINKTANK STRATEGIC OSINT V2 — Mobile
============================================

این نسخه، داشبورد موبایل را به یک بک‌اند واقعی Flask + SQLite متصل می‌کند.

اجرا روی کامپیوتر:
1) Python 3.10+ نصب باشد.
2) داخل این پوشه:
   python -m venv .venv
3) فعال‌سازی:
   Windows: .venv\Scripts\activate
   Linux/Mac: source .venv/bin/activate
4) نصب:
   pip install -r requirements.txt
5) اجرا:
   python app.py
6) سپس در Chrome:
   http://127.0.0.1:8000

برای استفاده از موبایل:
- اگر سرور روی کامپیوتر و موبایل در یک Wi‑Fi هستند، آدرس IP کامپیوتر را با پورت 8000 در Chrome موبایل باز کنید.
- برای استفاده از هرجا، پروژه را روی یک سرور/هاست HTTPS مستقر کنید.

منابع V2:
Reuters, INSS, CSIS, Crisis Group, IISS, RUSI
داده‌ها از RSS عمومی Google News گردآوری و در SQLite ذخیره می‌شوند.
این نسخه نمونه عملیاتی OSINT است و برای محیط تولیدی نیاز به احراز هویت، HTTPS، مدیریت secret، rate limiting و APIهای رسمی/پولی دارد.

نکته: تحلیل نظامی در این داشبورد در سطح راهبردی/غیرعملیاتی نگه داشته شده و شامل هدف‌گیری یا برنامه‌ریزی حمله نیست.
